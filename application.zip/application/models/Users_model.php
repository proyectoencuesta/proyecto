<?php
	class Users_model extends CI_Model {
		function __construct(){
			parent::__construct();
			$this->load->database();
		}
 
		public function login($nombre, $contrasena){
			$query = $this->db->get_where('usuarios', array('nombre'=>nombre, 'contrasena'=>$contrasena));
			return $query->row_array();
		}
 
	}
?>