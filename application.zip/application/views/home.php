<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>bootstrap/css/bootstrap.min.css">
</head>
<body>
<div class="container">
	<h1 class="page-header text-center">Bienvenido al sistema de encuesta </h1>
	</div>
	<div class="row">
		<div class="col-md-4 col-md-offset-4">
			<?php
				$user = $this->session->userdata('user');
				extract($user);
			?>
			<h2>Welcome to Homepage </h2>
			<div class="col-md-4 col-md-offset-4">
			
			<h4>User Info:</h4>
			<p>Fullname: <?php echo $fname; ?></p>
			<div class="col-md-8 col-md-offset-8">
			
			<p>nombre: <?php echo $nombre; ?></p>
			<div class="col-md-8 col-md-offset-8">
			
			<p>contrasena: <?php echo $contrasena; ?></p>
			<a href="<?php echo base_url(); ?>index.php/user/logout" class="btn btn-danger">Logout</a>
		</div>
	</div>
</div>
</body>
</html>